document.write('<applet name="PC128S" width="768" height="540" code="jemu.ui.JEMU.class" codebase="./">');
document.write('<param name="archive" value="pc128s.jar">');
document.write('<param name="COMPUTER" value="PC128S">');
document.write('<param name="SELECTOR" value="false">');
document.write('</applet>');